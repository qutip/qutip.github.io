expt1 = data.expect[0]
expt10 = data.expect[1]
expt100 = data.expect[2]
expt1000 = data.expect[3]