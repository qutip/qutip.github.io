f_modes_t = floquet_modes_t(f_modes_0, f_energies, 2.5, H, T, args)
f_modes_t # doctest: +SKIP
# [Quantum object: dims = [[2], [1]], shape = (2, 1), type = ket
# Qobj data =
# [[-0.89630512-0.23191946j]
# [ 0.37793106-0.00431336j]],
# Quantum object: dims = [[2], [1]], shape = (2, 1), type = ket
# Qobj data =
# [[-0.37793106-0.00431336j]
# [-0.89630512+0.23191946j]]]
