psi0 = rand_ket(2)
f_coeff = floquet_state_decomposition(f_modes_0, f_energies, psi0)
f_coeff # doctest: +SKIP
# [(-0.645265993068382+0.7304552549315746j),
# (0.15517002114250228-0.1612116102238258j)]
