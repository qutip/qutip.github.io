import pylab as plt
from scipy import *
from qutip import *
import numpy as np