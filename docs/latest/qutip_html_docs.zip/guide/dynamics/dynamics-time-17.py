opts = Options(rhs_reuse=True)
rhs_generate(H_td, c_ops, Hargs, name='lz_func')