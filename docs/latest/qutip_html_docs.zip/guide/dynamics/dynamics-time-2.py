def H1_coeff(t, args):
    return 9 * np.exp(-(t / 5.) ** 2)