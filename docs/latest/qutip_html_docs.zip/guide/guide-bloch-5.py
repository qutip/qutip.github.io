up = qutip.basis(2, 0)
b.add_states(up)
b.render()