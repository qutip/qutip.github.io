b.fig.clf()
vec = [0, 1, 0]
b.add_vectors(vec)
b.render()