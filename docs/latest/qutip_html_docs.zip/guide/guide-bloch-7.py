b.clear()
b.render()