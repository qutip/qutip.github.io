chi = qpt(U_rho, op_basis)

fig = qpt_plot_combined(chi, op_label, r'$i$SWAP')

plt.show()