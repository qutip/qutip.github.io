from qutip.qip.operations import iswap

U_psi = iswap()