input_data = file_data_read('expect.dat')
plt.plot(input_data[:,0], input_data[:,1]);  # plot the data