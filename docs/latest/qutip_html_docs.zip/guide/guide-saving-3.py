file_data_store('expect.dat', output_data.T, numtype="real", numformat="exp")
