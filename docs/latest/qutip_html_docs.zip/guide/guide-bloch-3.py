pnt = [1/np.sqrt(3), 1/np.sqrt(3), 1/np.sqrt(3)]
b.add_points(pnt)
b.render()