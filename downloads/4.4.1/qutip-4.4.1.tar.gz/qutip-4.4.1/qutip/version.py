# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '4.4.1'
version = '4.4.1'
release = True
