# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '4.2.0'
version = '4.2.0'
release = True
