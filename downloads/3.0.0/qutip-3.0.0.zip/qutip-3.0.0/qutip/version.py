# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '3.0.0'
version = '3.0.0'
release = True
