# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '4.0.2'
version = '4.0.2'
release = True
