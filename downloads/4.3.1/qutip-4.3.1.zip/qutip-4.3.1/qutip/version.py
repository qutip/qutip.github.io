# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '4.3.1'
version = '4.3.1'
release = True
