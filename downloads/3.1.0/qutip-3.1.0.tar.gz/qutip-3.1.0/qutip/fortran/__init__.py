try:
    from qutip.fortran.mcsolve_f90 import mcsolve_f90
except:
    pass
