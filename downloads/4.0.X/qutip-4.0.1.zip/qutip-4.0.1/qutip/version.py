# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '4.0.1'
version = '4.0.1'
release = True
