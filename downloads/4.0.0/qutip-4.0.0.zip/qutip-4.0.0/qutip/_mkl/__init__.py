import qutip.settings as qset
from qutip._mkl.utilities import _set_mkl
_set_mkl()