# THIS FILE IS GENERATED FROM QUTIP SETUP.PY
short_version = '4.1.0'
version = '4.1.0'
release = True
